function highlight() {
	// write your code
	// change the background color style to yellow
	document.getElementById("content").style.background = 'yellow';

}

function off() {
	// write your code
	// change the background color style to white
	document.getElementById("content").style.background = 'white';
}

